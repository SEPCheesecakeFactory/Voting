package Client.ChangeUsername;

public interface ChangeUsernameService {
  // TODO: define ChangeUsername model interface
}