package Client.ClosePoll;

public interface ClosePollService {
  // TODO: define ClosePoll model interface
}