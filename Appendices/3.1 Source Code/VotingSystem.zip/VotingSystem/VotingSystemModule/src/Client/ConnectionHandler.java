package Client;

/// This is the real service (should implement the same interface as the proxy)
public class ConnectionHandler
{
}
