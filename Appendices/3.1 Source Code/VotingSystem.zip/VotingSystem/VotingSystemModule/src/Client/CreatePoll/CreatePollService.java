package Client.CreatePoll;

import Common.Poll;

public interface CreatePollService
{
  void createPoll(Poll poll);
}
