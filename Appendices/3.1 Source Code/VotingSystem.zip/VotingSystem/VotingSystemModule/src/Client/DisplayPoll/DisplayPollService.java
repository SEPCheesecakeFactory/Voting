package Client.DisplayPoll;

public interface DisplayPollService
{
  void sendPollRequest(int pollID);
}