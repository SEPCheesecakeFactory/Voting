package Client.Login;

public interface LoginModelService
{
  // TODO: define Login model interface
}