package Client;

public enum ViewType
{
  Menu,
  General,
  PollResult,
  CreatePoll,
  DisplayPoll,
  Login,
  ChangeUsername,
  ClosePoll,
  Test,
  GUITest,
  HomeScreen,
  CreateGroup,
  AddUsersGroups,
  AvailablePolls
}
