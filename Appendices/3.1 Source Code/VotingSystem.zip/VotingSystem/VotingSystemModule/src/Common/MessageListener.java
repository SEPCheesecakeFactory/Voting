package Common;

public interface MessageListener
{
  void receiveMessage(Message message);
}
